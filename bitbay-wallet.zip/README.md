### Run locally (for testing)
There is no special instruction to run this locally
just download the code (git pull) and open up index.html in your browser.
